<?php
/* Template para mostrar la tienda personalizada */

get_header();

// Mostrar contenido de la plantilla
while (have_posts()) : the_post();
    the_content();
endwhile;

get_footer();
