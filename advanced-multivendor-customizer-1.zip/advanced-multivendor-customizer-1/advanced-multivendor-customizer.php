<?php
/**
 * Plugin Name: Advanced Multivendor Customizer
 * Description: Configura y personaliza las tiendas de vendedores de Dokan.
 * Version: 1.3
 * Author: Tu Nombre
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir ruta base del plugin
define('AMC_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Registrar tipo de contenido personalizado para plantillas de tiendas
function amc_register_store_templates() {
    $labels = array(
        'name' => __('Store Templates', 'amc'),
        'singular_name' => __('Store Template', 'amc'),
        'add_new' => __('Add New Template', 'amc'),
        'add_new_item' => __('Add New Store Template', 'amc'),
        'edit_item' => __('Edit Store Template', 'amc'),
        'new_item' => __('New Store Template', 'amc'),
        'view_item' => __('View Store Template', 'amc'),
        'search_items' => __('Search Store Templates', 'amc'),
        'not_found' => __('No Store Templates Found', 'amc'),
        'not_found_in_trash' => __('No Store Templates Found in Trash', 'amc'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'store-template'),
        'supports' => array('title', 'editor', 'thumbnail'),
    );

    register_post_type('store_template', $args);
}
add_action('init', 'amc_register_store_templates');

// Incluir funciones adicionales
require_once AMC_PLUGIN_PATH . 'includes/template-manager.php';
require_once AMC_PLUGIN_PATH . 'includes/store-fields.php';
require_once AMC_PLUGIN_PATH . 'includes/link-redirector.php';

// Registrar menú en el panel de administración
function amc_register_admin_menu() {
    add_menu_page(
        __('Multivendor Customizer', 'amc'),
        __('Customizer', 'amc'),
        'manage_options',
        'amc-settings',
        'amc_admin_page',
        'dashicons-store',
        25
    );

    add_submenu_page(
        'amc-settings',
        __('Store Templates', 'amc'),
        __('Templates', 'amc'),
        'manage_options',
        'edit.php?post_type=store_template'
    );

    add_submenu_page(
        'amc-settings',
        __('Vendor Settings', 'amc'),
        __('Vendors', 'amc'),
        'manage_options',
        'amc-vendor-settings',
        'amc_vendor_settings_page'
    );
}
add_action('admin_menu', 'amc_register_admin_menu');

// Página principal del plugin
function amc_admin_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Advanced Multivendor Customizer', 'amc'); ?></h1>
        <p><?php esc_html_e('Configura y personaliza las tiendas de tus vendedores.', 'amc'); ?></p>
    </div>
    <?php
}
