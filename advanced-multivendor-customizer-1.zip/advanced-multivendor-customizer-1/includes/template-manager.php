<?php
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Obtener todas las plantillas disponibles
function amc_get_store_templates() {
    $args = array(
        'post_type' => 'store_template',
        'posts_per_page' => -1,
    );
    return get_posts($args);
}
