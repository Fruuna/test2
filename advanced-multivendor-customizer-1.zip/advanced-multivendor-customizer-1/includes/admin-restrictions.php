<?php
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Restricciones de administración para los vendedores
function amc_restrict_admin_access() {
    // Implementar lógica para restringir acceso
}
