<?php
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Agregar un metabox para asignar plantillas a las tiendas Dokan
function amc_add_vendor_meta_box() {
    add_meta_box(
        'amc_vendor_template',
        __('Assign Store Template', 'amc'),
        'amc_render_vendor_meta_box',
        'dokan_store', // Suponiendo que "dokan_store" es el tipo de post usado por Dokan
        'side',
        'default'
    );
}
add_action('add_meta_boxes', 'amc_add_vendor_meta_box');

function amc_render_vendor_meta_box($post) {
    $template_id = get_post_meta($post->ID, '_amc_store_template', true);
    $templates = amc_get_store_templates();

    ?>
    <label for="amc_store_template"><?php esc_html_e('Select a Store Template', 'amc'); ?></label>
    <select name="amc_store_template" id="amc_store_template">
        <option value=""><?php esc_html_e('None', 'amc'); ?></option>
        <?php foreach ($templates as $template): ?>
            <option value="<?php echo esc_attr($template->ID); ?>" <?php selected($template_id, $template->ID); ?>>
                <?php echo esc_html($template->post_title); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}

function amc_save_vendor_meta_box($post_id) {
    if (isset($_POST['amc_store_template'])) {
        update_post_meta($post_id, '_amc_store_template', sanitize_text_field($_POST['amc_store_template']));
    }
}
add_action('save_post', 'amc_save_vendor_meta_box');
