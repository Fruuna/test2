<?php
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Redirigir enlaces de la tienda Dokan a la plantilla asignada
function amc_redirect_store_links() {
    if (is_singular('dokan_store')) {
        $store_user_id = get_post_field('post_author', get_the_ID());
        $template_id = get_user_meta($store_user_id, '_amc_store_template', true);

        if ($template_id) {
            $template_url = get_permalink($template_id);
            if ($template_url) {
                wp_redirect($template_url, 301);
                exit;
            }
        }
    }
}
add_action('template_redirect', 'amc_redirect_store_links');
