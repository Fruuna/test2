<?php
// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Funciones relacionadas con la gestión de productos (pendiente de implementación)
function amc_manage_products() {
    // Implementa la lógica para manejar productos en el futuro
}
